<h1 align="center">🛒 Vinted Bot 🛒</h1>


<h2 align="center">📷 Présentation du bot</h2>
<p align="center">Voici quelque image d'aticle du bot</p>
<p align="center">
<img align="center" src="https://i.ibb.co/TWWjGH8/Capture.png"></img>
</p>
<p align="center">
 <img src="https://i.ibb.co/RgqYhDs/Capture.png"></img>
 </p>
<p align="center"> Vous pouvez modifier la couleur du text, l'embed, les informations que vous voulez avoir
<img src="https://i.ibb.co/xM2jd6N/Capture.png"></img>
</p>
 

<h2 align="center"> 🔩 Comment setup le bot ?</h2>
<p align="center"> Lien de la vidéo youtube :<a href="https://youtu.be/eaStcisD9ow"> cliquez ici</a></p>

<h2 align="center"> 🛠️ Que peut-on faire avec le bot vinted</h2>
<p align="center">
<ul><strong>Fonctionnalité :</strong>
     <li>- Changer d'URL</li>
     <li>- Supprimer un sub</li>
     <li>- Modifier ce que vous voulez voir dans l'embed</li>
     <li>- Modifier la couleur de l'embed et la couleur du texte</li>
</ul>
<h2 align="center"> 🎟️ En cas de problème ?</h2>
<p align="center">Rejoignez nous sur le discord :<a href="https://discord.gg/spyy"> cliquez ici</a> et ouvrez un ticket le staff s'occupera de votre demande</p>
